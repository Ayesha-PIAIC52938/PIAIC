# Exploratery Data Analysis (EDA) practice using Pandas-library 

open jupyter note book from this directory (pandas liberary)
