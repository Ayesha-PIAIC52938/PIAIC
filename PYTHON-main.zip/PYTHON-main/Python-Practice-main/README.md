# Python-Practice
different codes to understand python language

Topics:
1.  print statement
2.  variabel types and decleration
3.  string methods
4.  input statement
5.  if else and elif
6.  lists
7.  tuples
8.  dictionaries                                      
9.  for loop
10. while loop
11. Functions
12. Classes
13. File Handelinh in Python
14. CSV files
15. Writing/reading json file in python
16. Exception handeling