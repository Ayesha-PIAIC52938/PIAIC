# PYTHON
assignment and practic code to learn Python
