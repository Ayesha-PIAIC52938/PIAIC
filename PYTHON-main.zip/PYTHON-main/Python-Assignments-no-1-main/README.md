# Python-Assignments
Python assignments throughout the course

Assignment 1

q1. Take two numbers from a user and check if the numbers are even or odd 

q2. Take name and subject marks from a user and

        1. find marks obtained
        
        2. percentage (each subject is worth 100 marks)
        
        3. print it in a tabular form
        
q3.   Repeat task 2 for five users and print |Name | Percentage| in table form
