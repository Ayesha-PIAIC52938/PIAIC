'''_____________________________________________________________________________________________________________________________________________________________________________________
                Question 3: Use for loop to generate the following sequences(0-100):
                                a. Odd numbers
                                b. Even numbers
                                c. Prime numbers
________________________________________________________________________________________________________________________________________________________________________________________'''

# a. Odd number sequence
print("Odd sequence:")
for odd in range(1,101,2):
    print( odd , end =" ")
print("\n")


# b. Even number sequence
print("Even sequence:")
for even in range(0,101,2):
    print( even , end =" ")
print("\n")

# c. Prime number sequence
