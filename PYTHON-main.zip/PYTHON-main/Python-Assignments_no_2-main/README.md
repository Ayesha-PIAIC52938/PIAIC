# Python-Assignments_no_2 
Assignment 2

QUESTIONS:
1. Print table of 2 (1-10) using for loop


2. Take a number from user and print a table from 1-10 using loops


3. Use for loop to generate the following sequences(0-100):
        
	a. Odd numbers
	
        b. Even numbers
	
        c. Prime numbers
        
        
4. Generate 100 random numbers between 10 -90 and 
      
	a. store them in assending order
	
        b. find all numbers grater than 40
	
        c. filter out numbers grater then 40 using continue statement
        
        
5. Generate 100 random numbers between 10-90 and find
        
	a. sum
	
        b. mean, median and mode
	
        c.minimum and maximum value
 
6. Ask users to provide 2 lists of fruits (same length). Compare the lists and see if it has common elements


7. Generate a random number between 1-10 and make user guess the number (provide 3 chances only)


8. Generate 100 random numbers between 10 -90 and remove elements that appears more then once


9. Take a long string from user and 

        a. count the repeated characters
	
        b. count number of spaces and guess the number of words in the string


10. Take input string from the user and count vovals and consonants 


11. Take string from user and find if palindrome or not


12. Type a code that prints the following outputs:

        
        a.  1 2 3 4 5 6 7      
            1 2 3 4 5 6
            1 2 3 4 5
            1 2 3 4
            1 2 3
            1 2
            1
         
        b.            5
                    4   4
                  3       3
                2           2
              1               1
                2           2
                  3       3
                    4   4
                      5
                     
