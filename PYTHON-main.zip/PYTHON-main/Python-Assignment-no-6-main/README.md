# Python-Assignment-n0-6

 question 1:  take an input fite (.txt file), create and save a new file each time you encounter an new line in the text within 
 
 question 2:  Creat an input mcq.txt file having 5 MCQ's (each MCQ worth 5 marks). Creat a program that takes user name and id and call the mcq.txt, user takes the test
              the code check user answers with the correct answer and print result.The code shoud perform this task for users until a certin key is pressed by user to 
              exit the quiz. 
              
question 3:   Task1. Make a file (.txt or .csv) that stores inventory (i.e product name, discription, quantity in stock). 
              
              Task2. Write a program thar:

                  a.  Asks a user whether he's admin or customer

                  b.  For admin: 

                      - Program should be able to add new products to inventory file

                      - Program should have the option to show sales statistics such as sale amount and quantity to the admin

                  c.  For customer:

                      - code should enable customer to view products

                      - see product details

                      - provide option for purchase or leave

                      - in case of putchase if customer required product quantity < available items, allow customer to buy that item.
                        Also update inventory records.

                      - if customer required product quantity > available items, inform customer about the minimum item he/she can buy.
                        Update inventory recordsif the user proceeds with the purchase.
        

              Quick note:
              Admin has the authority to see sales record and add new products
              Customer has access to product list and choice menue
              Update inventory records and creat sales recors, showing items sold and its quantity
