"""________________________________________________________________________________________________________________________________________________________________________________________

            question 2:  Creat an input mcq.txt file having 5 MCQ's (each MCQ worth 5 marks). Creat a program that takes user name and id and call the mcq.txt, user takes the test
                         the code check user answers with the correct answer and print result.The code shoud perform this task for users until a certin key is pressed by user to 
                          exit the quiz. 
___________________________________________________________________________________________________________________________________________________________________________________________"""

